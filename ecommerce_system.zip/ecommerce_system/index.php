<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce System</title>
    <link rel="stylesheet" href="styles.css">
    <script>

        function toggleForm(form) {
            const loginSection = document.getElementById('login');
            const registerSection = document.getElementById('register');
            
            if (form === 'login') {
                loginSection.style.display = 'block';
                registerSection.style.display = 'none';
            } else if (form === 'register') {
                loginSection.style.display = 'none';
                registerSection.style.display = 'block';
            }
        }
    </script>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Welcome to SnapShop</h1>
            <p>An E-Commerce-stop shop for all your posts!</p>
            <hr>
            <?php if (isset($_SESSION['username'])): ?>
                <p>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
                <a href="dashboard.php" class="btn">Go to Dashboard</a>
                <br>
                <a href="logout.php" class="btn">Logout</a>
            <?php else: ?>
                <!-- toggle between login and register -->
                <p>Would you like to...</p>
                <button onclick="toggleForm('login')" class="btn">Login</button>
                <button onclick="toggleForm('register')" class="btn">Register</button>
            <?php endif; ?>
        </section>

        <!-- Forms -->
        <?php if (!isset($_SESSION['username'])): ?>
        <section id="login" style="display: none;">
            <h2>Login</h2>
            <form action="login.php" method="POST">
                <label for="username">Username:</label>
                <input type="text" name="username" required>
                <label for="password">Password:</label>
                <input type="password" name="password" required>
                <button type="submit">Login</button>
            </form>
        </section>

        <section id="register" style="display: none;">
            <h2>Register</h2>
            <form action="register.php" method="POST">
                <label for="username">Username:</label>
                <input type="text" name="username" required>
                <label for="password">Password:</label>
                <input type="password" name="password" required>
                <button type="submit">Register</button>
            </form>
        </section>
        <?php endif; ?>
    </main>

    <!-- Footer Section -->
    <footer>
        <p>&copy; <?php echo date("Y"); ?> E-Commerce System. All rights reserved.</p>
    </footer>
</body>
</html>
