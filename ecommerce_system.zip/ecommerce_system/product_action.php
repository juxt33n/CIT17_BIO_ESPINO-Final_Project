<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'user_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    // add a new product
    if ($action === 'add') {
        $name = $_POST['product_name'];
        $price = $_POST['product_price'];
        $image = $_FILES['product_image']['name'];
        $target = "uploads/" . basename($image);

        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target)) {
            $sql = "INSERT INTO products (username, name, price, image) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssis", $username, $name, $price, $image);
            $stmt->execute();
            $stmt->close();
        }
        header("Location: dashboard.php");
        exit();
    }

    // edit a product
    if ($action === 'edit') {
        $id = $_POST['product_id'];
        $name = $_POST['product_name'];
        $price = $_POST['product_price'];
        $image = $_FILES['product_image']['name'];

        if (!empty($image)) {
            $target = "uploads/" . basename($image);
            move_uploaded_file($_FILES['product_image']['tmp_name'], $target);
            $sql = "UPDATE products SET name = ?, price = ?, image = ? WHERE id = ? AND username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sisii", $name, $price, $image, $id, $username);
        } else {
            $sql = "UPDATE products SET name = ?, price = ? WHERE id = ? AND username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("siii", $name, $price, $id, $username);
        }
        $stmt->execute();
        $stmt->close();
        header("Location: dashboard.php");
        exit();
    }

    // delete a product
    if ($action === 'delete') {
        $id = $_POST['product_id'];
        $sql = "DELETE FROM products WHERE id = ? AND username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $id, $username);
        $stmt->execute();
        $stmt->close();
        header("Location: dashboard.php");
        exit();
    }
}

$conn->close();
?>
