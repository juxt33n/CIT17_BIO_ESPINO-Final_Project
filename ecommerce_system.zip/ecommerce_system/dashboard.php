<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'user_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$username = $_SESSION['username'];
$sql = "SELECT * FROM products WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>

        <!-- add new product -->
        <form action="product_action.php" method="POST" enctype="multipart/form-data">
            <h3>Add Product</h3>
            <label for="product_name">Product Name:</label>
            <input type="text" name="product_name" required>
            <label for="product_price">Price (₱):</label>
            <input type="number" name="product_price" required>
            <label for="product_image">Product Image:</label>
            <input type="file" name="product_image" accept="image/*" required>
            <button type="submit" name="action" value="add">Add Product</button>
        </form>

        <h2>Here are your shop's product listings</h2>
        You may edit or delete your current listings.

        <!-- show products -->
        <div class="product-list">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="product">
                    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="Product Image">
                    <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                    <p>Price: ₱ <?php echo htmlspecialchars($row['price']); ?></p>

                    <!-- edit products -->
                    <form action="product_action.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <label for="product_name">Edit Name:</label>
                        <input type="text" name="product_name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                        <label for="product_price">Edit Price:</label>
                        <input type="number" name="product_price" value="<?php echo htmlspecialchars($row['price']); ?>" required>
                        <label for="product_image">Edit Image (Optional):</label>
                        <input type="file" name="product_image" accept="image/*">
                        <button type="submit" name="action" value="edit">Update</button>
                    </form>

                    <!-- delete products -->
                    <form action="product_action.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="action" value="delete">Delete</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </main>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
